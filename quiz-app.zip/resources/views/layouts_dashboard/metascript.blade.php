{{-- <!-- Required Jquery -->
<!-- JavaScript -->
<script src="{{asset('assets/js/bundle.js?ver=2.9.1')}}"></script>
<script src="{{asset('assets/js/scripts.js?ver=2.9.1')}}"></script> --}}

{{-- Vendor --}}
<script type="text/javascript" src="{{ asset('admin/vendor/jquery-ui/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/vendor/jquery-ui/jquery.blockUI.js') }}"></script>
{{-- <script type="text/javascript" src="{{asset('vendor/bootstrap/js/bootstrap.min.js')}}"></script> --}}

<!-- Datatable -->
<script src="{{ asset('admin/vendor/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin/vendor/libs/datatables-bs5/datatables-bootstrap5.js') }}"></script>
