<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
  id="layout-navbar">
  <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
    <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)"><i class="ti ti-menu-2 ti-sm"></i></a>
  </div>
  <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
    <div class="navbar-nav align-items-center">
      <div class="nav-item d-flex align-items-center">
        <h4 class="fw-bold mt-3"><span class="text-muted fw-light"><?php echo e($active); ?>/</span> <?php echo e($title); ?></h4>
        
      </div>
    </div>
    <ul class="navbar-nav flex-row align-items-center ms-auto">
      <!-- Notification -->
      
      <!--/ Notification -->
      <!-- User -->
      <li class="nav-item navbar-dropdown dropdown-user dropdown">
        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
          <div class="avatar avatar-online">
            <img src="<?php echo e(asset('admin/img/avatars/avatars-null.jpg')); ?>" alt class="h-auto rounded-circle" />
          </div>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li>
            <a class="dropdown-item" href="pages-account-settings-account.html">
              <div class="d-flex">
                <div class="flex-shrink-0 me-3">
                  <div class="avatar avatar-online">
                    <img src="<?php echo e(asset('admin/img/avatars/avatars-null.jpg')); ?>" alt class="h-auto rounded-circle" />
                  </div>
                </div>
                <div class="flex-grow-1">
                  <span class="fw-semibold d-block"><?php echo e(Auth::user()->email); ?></span>
                  <small class="text-muted"><?php echo e(Auth::user()->role); ?></small>
                </div>
              </div>
            </a>
          </li>
          
          <li>
            <div class="dropdown-divider"></div>
          </li>
          <li>
            <form action="<?php echo e(route('auth.logout')); ?>" class="d-inline" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="dropdown-item d-inline">
                <i class="ti ti-logout me-2 ti-sm"></i>
                <span class="align-middle">
                  <small>Log Out</small>
                </span>
              </button>
            </form>
          </li>
        </ul>
      </li>
      <!--/ User -->
    </ul>
  </div>
</nav>
<?php /**PATH E:\PROJECT\quiz-app\resources\views/layouts_dashboard/navbar.blade.php ENDPATH**/ ?>