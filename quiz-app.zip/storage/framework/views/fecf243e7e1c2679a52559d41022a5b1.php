<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="index.html" class="app-brand-link">
      <img src="<?php echo e(asset('user/assets/img/logo.svg')); ?>" height="40" alt="logo" />
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
      <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
      <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboards -->
    <li class="menu-item <?php echo e(request()->is('admin/dashboard*') ? 'active' : ''); ?>">
      <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-smart-home"></i>
        <div>Dashboards</div>
      </a>
    </li>
    <li class="menu-header small text-uppercase">
      <span class="menu-header-text">Master</span>
    </li>
    <li class="menu-item <?php echo e(request()->is('admin/operator*') ? 'active open' : ''); ?>">
      <a href="<?php echo e(route('admin.operator.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-user-check"></i>
        <div>Operator</div>
      </a>
    </li>
    <li class="menu-item <?php echo e(request()->is('admin/instansi*') ? 'active open' : ''); ?>">
      <a href="<?php echo e(route('admin.instansi.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-building-bank"></i>
        <div>Instansi</div>
      </a>
    </li>
    <li class="menu-item <?php echo e(request()->is('admin/sekolah*') ? 'active open' : ''); ?>">
      <a href="<?php echo e(route('admin.sekolah.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-school"></i>
        <div>Sekolah</div>
      </a>
    </li>
    
    <li class="menu-item <?php echo e(request()->is('admin/soal-awalan*') ? 'active open' : ''); ?>">
      <a href="/admin/soal-awalan" class="menu-link">
        <i class="menu-icon tf-icons ti ti-layout-sidebar-right"></i>
        <div>Soal Tes Awalan</div>
      </a>
    </li>
    <li class="menu-item <?php echo e(request()->is('admin/soal-lanjutan*') ? 'active open' : ''); ?>">
      <a href="/admin/soal-lanjutan" class="menu-link">
        <i class="menu-icon tf-icons ti ti-layout-sidebar"></i>
        <div>Soal Tes Lanjutan</div>
      </a>
    </li>
    
  </ul>
</aside>
<?php /**PATH E:\PROJECT\quiz-app\resources\views/layouts_dashboard/sidebar.blade.php ENDPATH**/ ?>