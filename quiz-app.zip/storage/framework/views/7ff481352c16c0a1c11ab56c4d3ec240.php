<?php $__env->startSection('content'); ?>
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <!-- Users List Table -->
    <div class="card">
      <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0">List Data <?php echo e($title); ?></h5>
        <a href="javascript:void(0)" id="addNewData" class="btn btn-primary">
          <span class="tf-icons bx bx-plus"></span>&nbsp; Tambah Data
        </a>
      </div>
      <div class="card-datatable table-responsive">
        <table id="<?php echo e($table_id); ?>" class="datatables-users-account table border-top">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Sekolah</th>
              <th>Alamat</th>
              <th>Keterangan</th>
              <th>Actions</th>
            </tr>
          </thead>
        </table>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="ajaxModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modelHeading">Modal title</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="javascript:void(0)" id="modalForm" name="modalForm" method="POST" class="form-horizontal">
              <?php echo csrf_field(); ?>
              <div class="modal-body">
                <input type="hidden" name="id" id="id">
                <div class="">
                  <div class="col mb-3">
                    <label for="nama_sekolah" class="form-label">Nama Sekolah <span style="color: red">*</span></label>
                    <input type="text" id="nama_sekolah" name="nama_sekolah" class="form-control"
                      placeholder="Masukkan nama instansi" />
                    <span class="invalid-feedback" id="nama_sekolah_error"></span>
                  </div>
                  <div class="col mb-3">
                    <label for="alamat" class="form-label">Alamat <span style="color: red">*</span></label>
                    <input type="text" id="alamat" name="alamat" class="form-control"
                      placeholder="Masukkan alamat sekolah" />
                    <span class="invalid-feedback" id="alamat_error"></span>
                  </div>
                  <div class="col mb-0">
                    <label for="keterangan" class="form-label">Keterangan</label>
                    <input type="text" id="keterangan" name="keterangan" class="form-control"
                      placeholder="masukkan keterangan/deskripsi" />
                    <span class="invalid-feedback" id="keterangan_error"></span>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">
                  Close
                </button>
                <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes</button>
              </div>
            </form>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!-- / Content -->
  <?php $__env->startPush('script'); ?>
    <script type="text/javascript">
      var table;
      $(document).ready(function() {
        table = $('#<?php echo e($table_id); ?>').DataTable({

          "language": {
            "lengthMenu": "_MENU_",
            /* 'loadingRecords': '&nbsp;',
            'processing': '<img src="<?php echo e(asset('assets/img/loader-sm.gif')); ?>"/>' */
          },
          processing: true,
          autoWidth: true,
          ordering: true,
          serverSide: true,
          ajax: {
            url: '<?php echo e(url('admin/getSekolah')); ?>',
            type: "POST",
            data: function(params) {
              params._token = "<?php echo e(csrf_token()); ?>";
            }
          },
          initComplete: function() {
            // Inisialisasi tooltip di dalam fungsi ini
            $('[data-bs-toggle="tooltip"]').tooltip();
          },
          language: {
            search: "",
            searchPlaceholder: "Type in to Search",
            lengthMenu: "<div class='d-flex justify-content-start form-control-select'> _MENU_ </div>",
            // info: "_START_ -_END_ of _TOTAL_",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_",
            infoEmpty: "No records found",
            infoFiltered: "( Total _MAX_  )",
            paginate: {
              "first": "First",
              "last": "Last",
              "next": "Next",
              "previous": "Prev"
            }
          },
          columns: [{
              data: 'DT_RowIndex',
              name: 'DT_RowIndex',
              orderable: false,
              searchable: false,
              class: 'text-left'
            },
            {
              data: 'nama_sekolah',
              name: 'nama_sekolah',
              orderable: true,
              searchable: true,
              class: 'text-left'
            },
            {
              data: 'alamat',
              name: 'alamat',
              orderable: true,
              searchable: true,
              class: 'text-left'
            },
            {
              data: 'keterangan',
              name: 'keterangan',
              orderable: true,
              searchable: true,
              class: 'text-left'
            },
            {
              data: 'action',
              name: 'id',
              orderable: false,
              searchable: false,
              class: 'text-center'
            }
          ]
        });

        $("#<?php echo e($table_id); ?>").DataTable().processing(true);
        $('#<?php echo e($table_id); ?>_filter input').unbind();
        $('#<?php echo e($table_id); ?>_filter input').bind('keyup', function(e) {
          if (e.keyCode == 13) {
            table.search(this.value).draw();
          }
        });
        $('.dataTables_filter').html(
          '<div class="input-group flex-nowrap"><span class="input-group-text" id="addon-wrapping"><i class="tf-icons ti ti-search"></i></span><input type="search" class="form-control form-control-sm" placeholder="Type in to Search" aria-label="Type in to Search" aria-describedby="addon-wrapping"></div>'
        );

        // Handle search input changes using DataTables API
        $('#<?php echo e($table_id); ?>_filter input').on('keyup', function() {
          table.search(this.value).draw();
        });
      });

      $('#addNewData').click(function() {
        $('#saveBtn').val("create-jenis");
        $('#id').val('');
        $('#modalForm').trigger("reset");
        $('#modelHeading').html("Tambah Data Sekolah");
        $('#ajaxModel').modal('show');
      });

      $('body').on('click', '.editData', function() {
        var id = $(this).data('id');
        $.get("<?php echo e(url('/admin/sekolah')); ?>" + '/' + id + '/edit', function(data) {
          $('#modelHeading').html("Edit Data Sekolah");
          $('#saveBtn').val("edit-jenis");
          $('#ajaxModel').modal('show');
          $('#id').val(data.id);
          $('#nama_sekolah').val(data.nama_sekolah);
          $('#alamat').val(data.alamat);
          $('#keterangan').val(data.keterangan);
        })
      });

      $('#saveBtn').click(function(e) {
        e.preventDefault();
        $(this).html('Sending..');

        // Remove the error handling for the "jenis" and "Nama" fields
        $('#jenis').removeClass('is-invalid');
        $('#jenis-error').remove();

        $.ajax({
          data: $('#modalForm').serialize(),
          url: "<?php echo e(url('/admin/sekolah')); ?>",
          type: "POST",
          dataType: 'json',
          success: function(data) {
            $('#modalForm').trigger("reset");
            $('#saveBtn').html('Simpan');
            $('#ajaxModel').modal('hide');
            if (data.success == 1) {
              Swal.fire({
                title: 'Sukses',
                text: data.msg,
                icon: 'success',
                customClass: {
                  confirmButton: 'btn btn-primary'
                },
                buttonsStyling: false
              });
            } else {
              Swal.fire({
                title: 'Gagal',
                text: data.msg,
                icon: 'error',
                customClass: {
                  confirmButton: 'btn btn-primary'
                },
                buttonsStyling: false
              });
            }
            table.draw();
          },
          error: function(data) {
            console.log('Error:', data);
            $('#saveBtn').html('Save Changes');

            // Error handling for specific input fields
            if (data.responseJSON.errors) {
              var errors = data.responseJSON.errors;
              $.each(errors, function(key, value) {
                $("#" + key).addClass("is-invalid");
                $("#" + key + "_error").text(value[0]);
              });
            }
          }
        });
      });

      function removeErrors() {
        $(".form-control").removeClass("is-invalid");
        $(".invalid-feedback").text("");
      }

      // Function to reset form and remove errors when modal is closed
      $("#ajaxModel").on("hidden.bs.modal", function() {
        $('#modalForm').trigger("reset");
        removeErrors();
      });

      function deleteData(id) {
        Swal.fire({
          icon: 'warning',
          text: 'Hapus Data Sekolah?',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete it!',
          customClass: {
            confirmButton: 'btn btn-primary me-3',
            cancelButton: 'btn btn-label-secondary'
          },
          buttonsStyling: false
        }).then((result) => {
          /* Read more about isConfirmed, isDenied below */
          if (result.isConfirmed) {
            $.ajax({
              url: "<?php echo e(url('/admin/sekolah')); ?>/" + id,
              data: {
                _method: "DELETE",
                _token: "<?php echo e(csrf_token()); ?>"
              },
              type: "POST",
              dataType: "JSON",
              success: function(data) {
                if (data.success == 1) {
                  table.draw();
                  Swal.fire({
                    title: 'Sukses',
                    text: data.msg,
                    icon: 'success',
                    customClass: {
                      confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                  });
                } else {
                  Swal.fire({
                    title: 'Gagal',
                    text: data.msg,
                    icon: 'error',
                    customClass: {
                      confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                  });
                }
              },
              error: function(error) {
                Swal.fire('Gagal', 'terjadi kesalahan sistem', 'error');
                console.log(error.XMLHttpRequest);
              }
            });
          }
        });
      }
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\quiz-app\resources\views/admin/sekolah/index.blade.php ENDPATH**/ ?>