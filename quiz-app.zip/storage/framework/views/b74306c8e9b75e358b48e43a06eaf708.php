


<script type="text/javascript" src="<?php echo e(asset('admin/vendor/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('admin/vendor/jquery-ui/jquery.blockUI.js')); ?>"></script>


<!-- Datatable -->
<script src="<?php echo e(asset('admin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
<?php /**PATH E:\PROJECT\quiz-app\resources\views/layouts_dashboard/metascript.blade.php ENDPATH**/ ?>