<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Quiz</title>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('admin/assets/img/avatars/stamp.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('admin/assets/img/avatars/stamp.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('admin/assets/img/avatars/stamp.png')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('admin/assets/img/avatars/stamp.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('user/assets/img/favicons/manifest.json')); ?>">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('admin/assets/img/avatars/stamp.png')); ?>">
    <meta name="theme-color" content="#ffffff">

    <link href="<?php echo e(asset('user/assets/css/theme.css')); ?>" rel="stylesheet" />

    <style>
      details {
        background-color: rgb(255, 255, 255);
        color: #000000;
        font-size: 1.1rem;
      }

      summary {
        padding: .5em 1.3rem;
        list-style: none;
        display: flex;
        justify-content: space-between;
        transition: height 1s ease;
      }

      summary::-webkit-details-marker {
        display: none;
      }

      summary:after {
        content: "\002B";
      }

      details[open] summary {
        border-bottom: 1px solid #aaa;
        margin-bottom: .5em;
      }

      details[open] summary:after {
        content: "\00D7";
      }

      details[open] div {
        padding: .5em 1em;
      }
    </style>
  </head>


  <body>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light sticky-top" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="/"><img src="<?php echo e(asset('user/assets/img/logo.svg')); ?>"
              height="40" alt="logo" /></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation"><span class="navbar-toggler-icon"> </span></button>
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto align-items-center">
              
              <?php if(auth()->guard()->check()): ?>
                <li class="nav-item navbar-dropdown dropdown-user dropdown d-flex ms-3">
                  <a class="nav-link" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img width="30" src="<?php echo e(asset('admin/assets/img/avatars/1.png')); ?>" alt
                        class="w-px-40 h-auto rounded-circle" />
                      <span class="ms-1"><?php echo e(Auth::user()->email); ?></span>
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img width="30" src="<?php echo e(asset('admin/assets/img/avatars/1.png')); ?>" alt
                                class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <small class="fw-semibold d-block"><?php echo e(Auth::user()->email); ?></small>
                            <small class="text-muted"><?php echo e(Auth::user()->role); ?></small>
                          </div>
                        </div>
                      </a>
                    </li>
                    
                    <li>
                      <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">
                        <i class="bx bx-list-ul me-2"></i>
                        <small>Dashboard</small>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <form action="<?php echo e(route('auth.logout')); ?>" class="d-inline" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item d-inline">
                          <i class="bx bx-power-off me-2"></i>
                          <span class="align-middle">
                            <small>Log Out</small>
                          </span>
                        </button>
                      </form>
                    </li>
                  </ul>
                </li>
              <?php endif; ?>
            </ul>
            <?php if(auth()->guard()->guest()): ?>
              <div class="d-flex ms-lg-4">
                <a class="btn btn-secondary-outline" href="<?php echo e(route('auth.login')); ?>">Masuk</a>
                
              </div>
            <?php endif; ?>
          </div>
        </div>
      </nav>
      <section class="pt-7" id="home">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6 text-md-start text-center py-5">
              <h1 class="mb-4 fs-9 fw-bold">Quiz Online Terbaik untuk Kemajuan Akademis Anda</h1>
              <p class="mb-6 lead text-secondary">Nikmati kemudahan mengelola ujian, pantauan proktor canggih, dan
                analisis hasil yang mendalam untuk mendukung kemajuan akademis Anda.</p>
              <div class="text-center text-md-start"><a class="btn btn-warning me-3 btn-lg" href="/login"
                  role="button">Coba Sekarang!</a></div>
            </div>
            <div class="col-md-6 text-end"><img class="pt-7 pt-md-0 img-fluid"
                src="<?php echo e(asset('user/assets/img/hero/hero-img.png')); ?>" alt="" /></div>
          </div>
        </div>
      </section>

      <!-- ============================================-->
      <!-- <section> begin ============================-->
      
      <!-- <section> close ============================-->
      <!-- ============================================-->


      <!-- ============================================-->
      <!-- <section> begin ============================-->
      
      <!-- <section> close ============================-->
      <!-- ============================================-->

      <!-- ============================================-->
      <!-- <section> begin ============================-->
      
      <!-- <section> close ============================-->
      <!-- ============================================-->

      <!-- ============================================-->
      <!-- <section> begin ============================-->
      
      <!-- <section> close ============================-->
      <!-- ============================================-->

      <!-- ============================================-->
      <!-- <section> begin ============================-->
      <section class="text-center py-0">
        <div class="container">
          <div class="container border-top py-3">
            <div class="row justify-content-between">
              <div class="col-12 col-md-auto mb-1 mb-md-0">
                <p class="mb-0">&copy; 2023 QUIZ </p>
              </div>
              <div class="col-12 col-md-auto">
                <p class="mb-0">QUIZ</p>
              </div>
            </div>
          </div>
        </div><!-- end of .container-->
      </section>
      <!-- <section> close ============================-->
      <!-- ============================================-->

    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->

    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?php echo e(asset('user/vendors/@popperjs/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendors/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendors/is/is.min.js')); ?>"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?php echo e(asset('user/vendors/fontawesome/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/assets/js/theme.js')); ?>"></script>

    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&amp;family=Volkhov:wght@700&amp;display=swap"
      rel="stylesheet">
  </body>

</html>
<?php /**PATH E:\PROJECT\quiz-app\resources\views/welcome.blade.php ENDPATH**/ ?>