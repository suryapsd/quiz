
<?php $__env->startSection('content'); ?>
  <div class="container-xxl flex-grow-1 container-p-y">
    <a href="/admin/soal-awalan/<?php echo e($id_instansi); ?>/tambah-soal" class="btn btn-outline-primary mb-3">
      <span class="tf-icons bx bx-left-arrow-alt"></span>&nbsp; Kembali
    </a>
    <div class="card mb-4">
      <h5 class="card-header">Tambah Soal Awalan Instansi <?php echo e($instansi->nama_instansi); ?></h5>
      <form class="card-body" action="/admin/soal-awalan/<?php echo e($id_instansi); ?>/tambah-soal" method="post"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-3">
          <label for="soal">Soal</label>
          <textarea name="soal" id="soal" cols="5" rows="5"
            class="form-control <?php $__errorArgs = ['soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo old('soal'); ?></textarea>
          <?php $__errorArgs = ['soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row g-3 mb-2">
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="jawaban_a">Jawaban A</label>
              <textarea name="jawaban_a" id="jawaban_a" cols="5" rows="5"
                class="form-control <?php $__errorArgs = ['jawaban_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo old('jawaban_a'); ?></textarea>
              <?php $__errorArgs = ['jawaban_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="jawaban_b">Jawaban B</label>
              <textarea name="jawaban_b" id="jawaban_b" cols="5" rows="5"
                class="form-control <?php $__errorArgs = ['jawaban_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo old('jawaban_b'); ?></textarea>
              <?php $__errorArgs = ['jawaban_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="jawaban_c">Jawaban C</label>
              <textarea name="jawaban_c" id="jawaban_c" cols="5" rows="5"
                class="form-control <?php $__errorArgs = ['jawaban_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo old('jawaban_c'); ?></textarea>
              <?php $__errorArgs = ['jawaban_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col-md-6 mb-2">
            <div class="form-group">
              <label for="jawaban_d">Jawaban D</label>
              <textarea name="jawaban_d" id="jawaban_d" cols="5" rows="5"
                class="form-control <?php $__errorArgs = ['jawaban_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo old('jawaban_d'); ?></textarea>
              <?php $__errorArgs = ['jawaban_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col">
            <div class="form-group">
              <label for="kunci_jawaban">Kunci Jawaban</label>
              <select class="form-select <?php $__errorArgs = ['kunci_jawaban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kunci_jawaban"
                aria-label="Default select example">
                <option value="">Pilih Kunci Jawaban</option>
                <option value="A" <?php echo e(old('kunci_jawaban') === 'A' ? 'selected' : ''); ?>>A
                </option>
                <option value="B" <?php echo e(old('kunci_jawaban') === 'B' ? 'selected' : ''); ?>>B
                </option>
                <option value="C" <?php echo e(old('kunci_jawaban') === 'C' ? 'selected' : ''); ?>>C
                </option>
                <option value="D" <?php echo e(old('kunci_jawaban') === 'D' ? 'selected' : ''); ?>>D
                </option>
              </select>
              <?php $__errorArgs = ['kunci_jawaban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
        <div class="pt-4">
          <button type="submit" class="btn btn-primary me-sm-3 me-1">Simpan Soal</button>
          <a href="/admin/jenis-soal" class="btn btn-label-secondary">Kembali</a>
        </div>
    </div>
    </form>
  </div>

  <?php $__env->startPush('script'); ?>
    <script type="text/javascript">
      document.addEventListener("DOMContentLoaded", function() {
        CKEDITOR.replace(`soal`, {
          filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token()])); ?>",
          filebrowserUploadMethod: 'form'
        });
        CKEDITOR.replace(`jawaban_a`, {
          filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token()])); ?>",
          filebrowserUploadMethod: 'form'
        });
        CKEDITOR.replace(`jawaban_b`, {
          filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token()])); ?>",
          filebrowserUploadMethod: 'form'
        });
        CKEDITOR.replace(`jawaban_c`, {
          filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token()])); ?>",
          filebrowserUploadMethod: 'form'
        });
        CKEDITOR.replace(`jawaban_d`, {
          filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token()])); ?>",
          filebrowserUploadMethod: 'form'
        });
      });
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\quiz-app\resources\views/admin/soal_awalan/add.blade.php ENDPATH**/ ?>